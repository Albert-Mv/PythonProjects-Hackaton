# -*- coding: utf-8 -*-
from __future__ import absolute_import

__version__ = "0.0.1"
__author__ = "Christoph Friedrich <christoph.friedrich@vonaffenfels.de>"

from .core import RGBMatrix, FrameCanvas, RGBMatrixOptions
